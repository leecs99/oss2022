package application;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

public class setting {
	
	@FXML private Button madd_btn;		
	@FXML private Button mdelete_btn;
	@FXML private Button back_btn;

// �޴� �߰� ��ư
public void add (ActionEvent event)  {
		
	Alert alert = new Alert(AlertType.INFORMATION);
	alert.setTitle("�޴� �߰�"); 
	alert.setContentText("�߰��� �޴��� �Է����ּ���.");				
	alert.show();
		

	Parent Mainlayout;
		try {
			Mainlayout = FXMLLoader.load(getClass().getResource("Add Menu.fxml"));
			Stage nowStage = (Stage)madd_btn.getScene().getWindow();
			Scene sc = new Scene(Mainlayout);
			
			nowStage.setScene(sc);
	        nowStage.show();
	      
			
			} catch (IOException e) {
			 e.printStackTrace();
		}
	}
	

// �޴� ���� ��ư
public void delete (ActionEvent event)  {
	
	Alert alert = new Alert(AlertType.INFORMATION);
	alert.setTitle("�޴� ����"); 
	alert.setContentText("������ �޴��� �Է����ּ���.");				
	alert.show();
	

	 Parent Mainlayout;
	try {
		Mainlayout = FXMLLoader.load(getClass().getResource("Delete Menu.fxml"));
		Stage nowStage = (Stage)mdelete_btn.getScene().getWindow();
		Scene sc = new Scene(Mainlayout);
		
		nowStage.setScene(sc);
        nowStage.show();
      
		
		} catch (IOException e) {
		 e.printStackTrace();
			}
	}
	
// ���� ȭ��
public void back (ActionEvent event)  {
		
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle("���� ȭ�� �̵�."); 
		alert.setContentText("���� ȭ������ �̵� �մϴ�.");
		alert.setHeaderText("���� ȭ�� �̵� �˸�!");				
		alert.show();
		

		 Parent Mainlayout;
		try {
			Mainlayout = FXMLLoader.load(getClass().getResource("Cafe Main.fxml"));
			Stage nowStage = (Stage)back_btn.getScene().getWindow();
			Scene sc = new Scene(Mainlayout);
			
			nowStage.setScene(sc);
	        nowStage.show();
	      
			
			} catch (IOException e) {
			 e.printStackTrace();
				}
			}
	
	}


