package application;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

public class AddMenuController {
	@FXML private Button open_btn;
	@FXML private Button back_btn;
	@FXML private Button add_btn;
	@FXML private TextField menu;
	@FXML private TextField price;
	@FXML private Label file;
	

public void open (ActionEvent event)  {
	
}	
	
	
// �ڷΰ��� -> ���� ȭ������ �̵�
public void back (ActionEvent event)  {
		
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle("���� ȭ�� �̵�."); 
		alert.setContentText("���� ȭ������ �̵� �մϴ�.");
		alert.setHeaderText("���� ȭ�� �̵� �˸�!");				
		alert.show();
		

		 Parent Mainlayout;
		try {
			Mainlayout = FXMLLoader.load(getClass().getResource("Setup.fxml"));
			Stage nowStage = (Stage)back_btn.getScene().getWindow();
			Scene sc = new Scene(Mainlayout);
			
			nowStage.setScene(sc);
	        nowStage.show();
	      
			
			} catch (IOException e) {
			 e.printStackTrace();
				}
			}
	
//�޴� �߰� -> ���� ȭ�� �̵�
public void add (ActionEvent event)  {
	
	Alert alert = new Alert(AlertType.INFORMATION);
	alert.setTitle("�޴� �߰�"); 
	alert.setContentText("�޴��� �߰��Ǿ����ϴ�.\n ���� ȭ������ �̵��մϴ�.");
	alert.setHeaderText("�޴� �߰�!");				
	alert.show();
	

	 Parent Mainlayout;
	try {
		Mainlayout = FXMLLoader.load(getClass().getResource("Cafe Main.fxml"));
		Stage nowStage = (Stage)add_btn.getScene().getWindow();
		Scene sc = new Scene(Mainlayout);
		
		nowStage.setScene(sc);
     nowStage.show();
   
		
		} catch (IOException e) {
		 e.printStackTrace();
			}
		}
	
	
	
}
